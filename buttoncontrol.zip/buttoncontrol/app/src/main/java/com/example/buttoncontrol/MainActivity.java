package com.example.buttoncontrol;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    CheckBox music, sports, reading;
    RadioGroup genderGroup;
    Button submit;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        music = findViewById(R.id.music);
        sports = findViewById(R.id.sports);
        reading = findViewById(R.id.reading);
        genderGroup = findViewById(R.id.genderGroup);
        submit = findViewById(R.id.submit);
        result = findViewById(R.id.result);

        submit.setOnClickListener(v -> {

            String hobbies = "";

            if(music.isChecked())
                hobbies += "Music ";

            if(sports.isChecked())
                hobbies += "Sports ";

            if(reading.isChecked())
                hobbies += "Reading ";

            int id = genderGroup.getCheckedRadioButtonId();
            RadioButton genderBtn = findViewById(id);
            String gender = genderBtn.getText().toString();

            result.setText("Hobbies: " + hobbies + "\nGender: " + gender);
        });
    }
}